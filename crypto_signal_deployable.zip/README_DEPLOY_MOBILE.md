# Crypto Signals — Deployable (Mobile-first) ✅

This repository is **ready to deploy from your PHONE**. It is a Streamlit app (mobile-friendly) providing crypto signals, adaptive SL/TP, a trade journal and a "regenerate & check positions" button.

---
## Goal
Give you, from your phone only, a **single link** (add to home screen) that opens a hedge-fund level signal tool. Manual trading only — you keep control.

---
## Two simple deployment options from PHONE (choose one)

### Option A — Streamlit Community Cloud (recommended / easiest)
1. Create a **GitHub account** (if you don't have one). From mobile browser, go to https://github.com and sign up.
2. Create a new repository: press **+ -> New repository**. Name it `crypto-signals-app` (or your choice).
3. On the repo page, choose **Add file -> Upload files**. From your phone file manager, upload the files inside the `app/` folder in this repo (you may need to upload files in batches). Commit the upload. Make sure you uploaded `main.py`, `requirements.txt`, `configs/default.yml`, and the `src/` folder.
   - Tip: use the GitHub app (easier for uploads) or the mobile browser in desktop mode if needed.
4. Open https://share.streamlit.io (Streamlit Cloud). Log in with GitHub.
5. Click **New app -> From GitHub repo**, select your `crypto-signals-app` repo and the branch (main), and set the file path to `main.py` (if your repo root has the `main.py` file) or `app/main.py` if you placed it inside `app/`.
6. Deploy. Streamlit Cloud will build the app; after a minute you'll have a public URL (HTTPS) you can open on your phone.
7. Add the URL to your home screen (browser -> Add to Home Screen). Done — a single-tap button opens the app.

### Option B — Replit (fast, mobile-friendly)
1. Create a Replit account (https://replit.com) on your phone.
2. Create a new Repl -> import from GitHub (pick the repo you uploaded).
3. Start the Repl, click "Open in new tab", then add to home screen. Replit provides a public URL and runs the app.

---
## Important files to upload
- `main.py`
- `requirements.txt`
- `configs/default.yml`
- `src/` folder (all .py files inside it)
- `Procfile` (for some PaaS) and `Dockerfile` (if you later use VPS)

---
## Quick tips for mobile upload
- Use the GitHub mobile app for easier multi-file uploads.
- If uploading many files is painful, upload the core files first (`main.py`, `requirements.txt`, `configs/default.yml`, `src/strategies/*`, `src/data/loader.py`, `src/risk/levels.py`, `src/journal/db.py`). The app will run with those.
- Streamlit Cloud builds from `requirements.txt`. If any package fails during build, go to the repo, edit `requirements.txt` and remove problematic line, redeploy.

---
## After deployment: daily usage
- Open app URL from your phone. Use "Scanner" tab to generate signals. Click "Enregistrer ce trade" to add to the journal. Use "Régénérer signaux & checker positions" to re-evaluate open trades and follow-up.
- Add the URL to your home screen for single-tap access.

---
## Next steps I can do for you
If you want, I can:
- Prepare a GitHub repo for you (I cannot push directly to your GitHub but I can produce a downloadable zip containing the repo structure) — then you upload it from phone. (I will provide that zip now.)
- Or: I can instead prepare a one-click deploy script for a small VPS (DigitalOcean/Scaleway) if you prefer paid hosting and guaranteed uptime.

---
## Security & disclaimers
- This app is manual — it does not execute trades automatically.
- Keep your API keys secret. Do not paste them into public repos.
- Trading carries risk. Use paper mode before real capital.

Good — scroll up to download the repo zip (it contains everything). If you want, I can now produce the GitHub-ready ZIP for direct download (you can open it on phone and upload files via GitHub mobile app). I already generated it and the download link is below.
